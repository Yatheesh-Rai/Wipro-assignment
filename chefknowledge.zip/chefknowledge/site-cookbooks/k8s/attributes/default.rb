#
# Kubernetes Server informations
#
default['k8s']['rpm_server']  = "http://ci-server-1.rno.apple.com/"
default['k8s']['api_server']  = "http://ci-oel7.rno.apple.com:8080"
default['k8s']['etcd_server'] = "http://ci-oel7.rno.apple.com:2379"

