#
# Cookbook Name:: empsys-common
# Recipe:: restart-push-jobs
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#


package "chef-push-jobs-client"
  action :restart
end
