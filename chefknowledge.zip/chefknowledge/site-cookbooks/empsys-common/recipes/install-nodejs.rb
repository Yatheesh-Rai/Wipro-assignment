#
# Cookbook Name:: empsys-common
# Recipe:: install-nodejs
#
# Copyright 2016, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

package "apple-nodejs" do
  action :install
end
