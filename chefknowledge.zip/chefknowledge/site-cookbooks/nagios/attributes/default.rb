#
# Kubernetes Server informations
#
default['nagios']['nrpe_pkg_server'] = "http://ci-server-1.rno.apple.com/"
default['nagios']['app_user_name']   = "empsysd"
